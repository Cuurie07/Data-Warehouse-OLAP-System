package statistics;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Properties;
import org.apache.commons.math.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.inference.TTest;

public class Ttest  {	
		int sample_id;
		double[] exp_c;
		double[] probe_c;
		Ttest(int sample_id,double[] exp_c,double[] probe_c){
			this.sample_id=sample_id;
			this.exp_c=exp_c;
			this.probe_c=probe_c;
		}
		Ttest(int sample_id,double[] exp_c){
			this.sample_id=sample_id;
			this.exp_c=exp_c;
		}
		Ttest(int sample_id){
			this.sample_id=sample_id;	
		}
		public Ttest() {
			// TODO Auto-generated constructor stub
		}
		private class subtest{
			int p_id;
			 ArrayList<Double> exp_c;
			 ArrayList<Double> probe_c;
			 subtest(int p_id ,ArrayList<Double> exp_c,ArrayList<Double> probe_c){
				 this.p_id=p_id;
				 this.exp_c=exp_c;
				 this.probe_c=probe_c;
			 }
		}
	private class test{
					int p_id;
					 double[] exp_c;
					 ArrayList<Double> exp_cd;
					 
					 test(int p_id ,double[] exp_c,ArrayList<Double> exp_cd){
						 this.p_id=p_id;
						 this.exp_c=exp_c;	
						 this.exp_cd=exp_cd;
					 }
	}
			private static Connection conn=null;
			
// Function to setup java connection		
public static Connection set_up() throws IOException, ClassNotFoundException, SQLException{
		Properties prop = new Properties();
        InputStream inputStream = DBUtility.class.getClassLoader().getResourceAsStream("config.properties");
        prop.load(inputStream);
        String driver = prop.getProperty("driver");
        String url = prop.getProperty("url");
        String user = prop.getProperty("user");
        String password = prop.getProperty("password");
        Class.forName(driver);
        conn = DriverManager.getConnection(url, user, password);
        return conn;		
	}


//Function to create ArrayList<Ttest> object
public static  ArrayList<Ttest>  table_read(Statement statement,String query)  throws SQLException{
	   
	    ArrayList<Ttest> ob = new ArrayList<Ttest>();
	    ResultSet resultset = statement.executeQuery(query);	
	    ArrayList<Double> coa= new ArrayList<Double>();	
	    while(resultset.next())
	  		{
	  			int s_id=Integer.parseInt(resultset.getString(1));
	  			String[] exp=resultset.getString(2).split(",");
	  			String[] probe=resultset.getString(3).split(",");
	  			int exp_len = exp.length;
	  			int probe_len=probe.length;
	  			double[] exp_c= new double[exp_len];
	  			double[] probe_c= new double[probe_len];
	  			for (int i=0;i<exp_len;i++){
	  			exp_c[i]=Double.parseDouble(exp[i]);
	  			}
	  			for (int i=0;i<probe_len;i++){
	  		 	probe_c[i]=Double.parseDouble(probe[i]);
	  	    	}				
	  			ob.add(new Ttest(s_id,exp_c,probe_c));	
}
	    return ob;
}

//Part 3 ALL_ALL
public static  ArrayList<Double> correlation_table_all(Statement statement) throws SQLException{
	 ArrayList<Ttest> ob = new ArrayList<Ttest>();
	 ArrayList<Double> coa= new ArrayList<Double>();	
	 String query="select * from correlation_table_all";
	 ob=table_read(statement,query);
	
		for (int i=0 ;i<ob.size();i++){
			double[] p1=ob.get(i).exp_c;
			for(int j=i+1;j<ob.size();j++){
				double[] p2=ob.get(j).exp_c;		
				double corr = new PearsonsCorrelation().correlation(p1, p2);
			//	System.out.println(ob.get(i).sample_id+","+ob.get(j).sample_id+":"+corr);
				coa.add(corr);
			}
		}
		
		return coa;
		
	}
//Take only informative genes from Text File
public  ArrayList<Ttest> clean_up_informative_gene(ArrayList<Ttest> ob,HashMap<Integer,Integer> map,int no){
	 ArrayList<Ttest> obj = new ArrayList<Ttest>();
	 for (int i=0;i<ob.size();i++){
		Ttest ttest=ob.get(i);
		double[] exp =ttest.exp_c;
		double[] uid=ttest.probe_c;
		double[] exp_final=new double[no];
		double[] uid_final=new double[no];
		int k=0;
		for (int j=0;j<exp.length;j++){
			int xx=(int) uid[j];
			if(map.get(xx)!=null){
				exp_final[k]=exp[j];
				uid_final[k]=uid[j];
				k++;
				
			}
			ttest.exp_c=exp_final;
			ttest.probe_c=uid_final;
		}
		obj.add(ttest);
	}
	 return obj;
}

//Maintain set of informative genes in hashmap
public HashMap<Integer,Integer> add_informative_gene(Statement statement) throws SQLException{
	 String query="select * from part32"; 
	 ResultSet resultset = statement.executeQuery(query);
	 HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
	  while(resultset.next())
		{
		int val1=Integer.parseInt(resultset.getString(1));
		map.put(val1,1);
		}
	  return map;
	 
}
//Calculate Average 
public static void cal_average( ArrayList<Double> coa){
	double af=0;
	for (int i=0;i<coa.size();i++){	
		af=af+coa.get(i);
	}
	double m=af/coa.size();
	System.out.println("Avg is : "+m);	
}

//Part 3 ALL_AML
public static ArrayList<Double> correlation_table_all_aml(Statement statement) throws SQLException{
	ArrayList<Ttest> ob1 = new ArrayList<Ttest>();
	ArrayList<Ttest> ob2 = new ArrayList<Ttest>();
	 ArrayList<Double> coa= new ArrayList<Double>();	
	 String query="select * from correlation_table_all";
	 ob1=table_read(statement,query);
	 query="select * from correlation_table_aml";
	 ob2=table_read(statement,query);
	
		for (int i=0 ;i<ob1.size();i++){
			double[] p1=ob1.get(i).exp_c;
			for(int j=0;j<ob2.size();j++){
				double[] p2=ob2.get(j).exp_c;		
				double corr = new PearsonsCorrelation().correlation(p1, p2);
			//	System.out.println(ob1.get(i).sample_id+","+ob2.get(j).sample_id+":"+corr);
				coa.add(corr);
			}
		}
		
		return coa;
		
	}

//Part 3 Correlation between ALL-PN
public   ArrayList<test> correlation_table_test_all(Statement statement) throws SQLException, IOException{
	ArrayList<Ttest> ob1 = new ArrayList<Ttest>();
	ArrayList<Ttest> ob2 = new ArrayList<Ttest>();
	ArrayList<test> ob3 = new ArrayList<test>();
	ArrayList<test> ob4 = new ArrayList<test>();
	ArrayList<Double> ob5 = new ArrayList<Double>();
	 ArrayList<Double> coa= new ArrayList<Double>();
		
	 String query="select * from part6";
	 ob1=table_read(statement,query);	
	  
	 ob2=read_file("test_samples.txt");
	 
	 HashMap<Integer,Integer> mp =add_informative_gene(statement);
	 int noofinformative =mp.size();
	 ob2=clean_up_informative_gene(ob2,mp,noofinformative);
	 for (int k=0;k<ob2.size();k++){
		 double[] exp =new double[ob1.size()];
		 ArrayList<Double> exp_list = new ArrayList<Double>();
		 
		 test test_ob= new test(k+1,exp,exp_list) ;
		 ob4.add(test_ob);
	 }
	
		for (int i=0 ;i<ob1.size();i++){
			double[] p1=ob1.get(i).exp_c;
			for(int j=0;j<ob2.size();j++){
				test test_ob=ob4.get(j);
			
				double[] p2=ob2.get(j).exp_c;		
				double corr = new PearsonsCorrelation().correlation(p1, p2);
				test_ob.exp_cd.add(corr);
				System.out.println(ob1.get(i).sample_id+","+ob2.get(j).sample_id+":"+corr);
				coa.add(corr);
			}
		}
		
		for(int h=0;h<ob2.size();h++){
			test test_ob=ob4.get(h);
			 ArrayList<Double> sp= test_ob.exp_cd;
			 double[] p1= new double[sp.size()];
			for (int l=0;l< sp.size();l++){
				p1[l]=sp.get(l);
			}
			test_ob.exp_c=p1;
		}
		return ob4;
   }

//Part 3 Correlation between NOT ALL-PN
public ArrayList<test> correlation_table_test_notall(Statement statement) throws SQLException, IOException{
	ArrayList<Ttest> ob1 = new ArrayList<Ttest>();
	ArrayList<Ttest> ob2 = new ArrayList<Ttest>();
	ArrayList<test> ob3 = new ArrayList<test>();
	ArrayList<test> ob4 = new ArrayList<test>();
	ArrayList<Double> ob5 = new ArrayList<Double>();
	 ArrayList<Double> coa= new ArrayList<Double>();
		
	 String query="select * from part7";
	 ob1=table_read(statement,query);	
	  
	 ob2=read_file("test_samples.txt");
	 
	 HashMap<Integer,Integer> mp =add_informative_gene(statement);
	 int noofinformative =mp.size();
	 ob2=clean_up_informative_gene(ob2,mp,noofinformative);
	 for (int k=0;k<ob2.size();k++){
		 double[] exp =new double[ob1.size()];
		 ArrayList<Double> exp_list = new ArrayList<Double>();
		 
		 test test_ob= new test(k+1,exp,exp_list) ;
		 ob4.add(test_ob);
	 }
	
		for (int i=0 ;i<ob1.size();i++){
			double[] p1=ob1.get(i).exp_c;
			for(int j=0;j<ob2.size();j++){
				test test_ob=ob4.get(j);
			
				double[] p2=ob2.get(j).exp_c;		
				double corr = new PearsonsCorrelation().correlation(p1, p2);
				test_ob.exp_cd.add(corr);
				System.out.println(ob1.get(i).sample_id+","+ob2.get(j).sample_id+":"+corr);
				coa.add(corr);
			}
		}
		
		for(int h=0;h<ob2.size();h++){
			test test_ob=ob4.get(h);
			 ArrayList<Double> sp= test_ob.exp_cd;
			 double[] p1= new double[sp.size()];
			for (int l=0;l< sp.size();l++){
				p1[l]=sp.get(l);
			}
			test_ob.exp_c=p1;
		}
		return ob4;
   }
//Function to read text file
//no of patients static value :should change noofpatients 
public  ArrayList<Ttest>  read_file(String filename) throws IOException{
	BufferedReader bf = new BufferedReader(new FileReader(filename));
	String header = bf.readLine();
	String row="";
	ArrayList<subtest> ob = new ArrayList<subtest>();
	ArrayList<Ttest> ob_c = new ArrayList<Ttest>();
	 ArrayList<Double> expression= new ArrayList<Double>();
	 ArrayList<Double> uid_list = new ArrayList<Double>();
	 
	int noofpatients=6;
	for (int i=0;i<noofpatients-1;i++){
		
		 ArrayList<Double> exp_c = new  ArrayList<Double>();
		 ArrayList<Double> probe_c= new  ArrayList<Double>();
		 subtest ttest = new subtest(i+1,exp_c,probe_c);
		ob.add(ttest);
	}
	while((row= bf.readLine())!=null){
		String[] data=row.split("\t");
		for (int  i=0;i<noofpatients-1;i++){
		ob.get(i).probe_c.add(Double.parseDouble(data[0]));
		}
		for (int  i=0;i<noofpatients-1;i++){
			ob.get(i).exp_c.add(Double.parseDouble((data[i+1])));
		}	
	}	
	for(int i=0;i<noofpatients-1;i++){
		int p=ob.get(i).p_id;
		ArrayList<Double> exp_d =ob.get(i).exp_c;
		double[] exp_c = new double[exp_d.size()];
		ArrayList<Double> pr_d =ob.get(i).probe_c;
		double[] pr_c = new double[pr_d.size()];
		for (int j=0;j<exp_d.size();j++){
			exp_c[j]=exp_d.get(j);
			pr_c[j]=pr_d.get(j);
		}
		
		Ttest tt= new Ttest(p,exp_c,pr_c);
	
		ob_c.add(tt);
	}
	

	return ob_c;
}
	public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException {
		Connection conn=set_up();
		Ttest tobj = new Ttest();
		Statement statement = conn.createStatement() ;
		System.out.println("Avg Value of Correlation between ALL-ALL");
		ArrayList<Double> coa1=correlation_table_all(statement);
		cal_average(coa1);
		System.out.println("Avg Value of Correlation between ALL-AML");
		ArrayList<Double> coa2=correlation_table_all_aml(statement);
		cal_average(coa2);
		
		System.out.println("Correlation Between Patients ALL and Patients N");
		ArrayList<test> coa=tobj.correlation_table_test_all(statement);
		System.out.println("Correlation Between Patients NOT ALL and Patients N");
		ArrayList<test> coa_notall=tobj.correlation_table_test_notall(statement);
		for(int i=0;i<coa_notall.size();i++){
			double[] arr1 = coa.get(i).exp_c;
			double[] arr2 = coa_notall.get(i).exp_c;
			int k=i+1;
			System.out.println("Test"+k +" :"+ new TTest().homoscedasticTTest(arr1,arr2));
		}
	
		
	}
}

